APP_ABI := arm64-v8a
APP_PLATFORM := android-23
APP_STL := c++_static
APP_OPTIM := release
APP_SHORT_COMMANDS := true
